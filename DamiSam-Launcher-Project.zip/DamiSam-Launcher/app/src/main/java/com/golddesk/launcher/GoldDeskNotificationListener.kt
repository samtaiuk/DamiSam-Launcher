package com.golddesk.launcher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class GoldDeskNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        getSharedPreferences("golddesk", MODE_PRIVATE).edit()
            .putInt("badge_${sbn.packageName}", activeNotifications?.count { it.packageName == sbn.packageName } ?: 1)
            .apply()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        sbn ?: return
        val count = activeNotifications?.count { it.packageName == sbn.packageName } ?: 0
        getSharedPreferences("golddesk", MODE_PRIVATE).edit()
            .putInt("badge_${sbn.packageName}", count).apply()
    }
}
