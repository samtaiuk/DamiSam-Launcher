package com.golddesk.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.appwidget.AppWidgetHost
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(28, 16, 22)
    private val panel = Color.rgb(57, 30, 42)
    private val gold = Color.rgb(255, 137, 167)
    private val cream = Color.rgb(255, 239, 244)
    private val prefs by lazy { getSharedPreferences("golddesk", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var appArea: LinearLayout
    private lateinit var search: EditText
    private var allApps: List<ApplicationInfo> = emptyList()
    private var drawerOpen = false
    private var downY = 0f
    private var downX = 0f
    private var pendingPackage: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderHome()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) refreshDashboard()
    }

    private fun background(color: Int, radius: Float = 22f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun label(text: String, size: Float, color: Int = cream, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(text: String, action: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text; textSize = 13f; setTextColor(gold)
            gravity = Gravity.CENTER; setPadding(14, 12, 14, 12)
            background = background(panel, 18f)
            setOnClickListener { action() }
        }

    private fun renderHome() {
        drawerOpen = false
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg)
            setPadding(20, 24, 20, 16)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = label("DamiSam", 22f, gold, true)
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("⚙", ::showSettings))
        root.addView(header)
        root.addView(label("MADE WITH LOVE • YOUR PERSONAL SPACE", 9f, Color.LTGRAY).apply { setPadding(0, 4, 0, 18) })
        val clock = label("", 38f, cream, true)
        root.addView(clock)
        val date = label("", 13f, gold)
        root.addView(date)
        val handler = Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                clock.text = SimpleDateFormat("h:mm", Locale.getDefault()).format(Date())
                date.text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()).uppercase(Locale.getDefault())
                handler.postDelayed(this, 30000)
            }
        }
        handler.post(tick)

        val cards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 18, 0, 14) }
        val weather = label("WEATHER\nYour day, with love", 12f, cream).apply {
            setPadding(14, 14, 14, 14); background = background(panel); gravity = Gravity.CENTER_VERTICAL
        }
        val system = label(systemStatusText(), 12f, cream).apply {
            setPadding(14, 14, 14, 14); background = background(panel); gravity = Gravity.CENTER_VERTICAL
        }
        cards.addView(weather, LinearLayout.LayoutParams(0, 84, 1f).apply { marginEnd = 8 })
        cards.addView(system, LinearLayout.LayoutParams(0, 84, 1f).apply { marginStart = 8 })
        root.addView(cards)
        val calendar = label("CALENDAR\nTap to view your calendar", 12f, cream).apply {
            setPadding(14, 13, 14, 13); background = background(panel)
            setOnClickListener { openCalendar() }
        }
        root.addView(calendar)
        root.addView(label("QUICK ACCESS", 10f, gold, true).apply { setPadding(0, 22, 0, 10) })
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quick.addView(button("All apps  ↑") { showDrawer() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 5 })
        quick.addView(button("Search  ⌕") { showDrawer(true) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = 5 })
        root.addView(quick)
        root.addView(label("FAVOURITES  ♥", 10f, gold, true).apply { setPadding(0, 20, 0, 8) })
        appArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(appArea)
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(label("SWIPE UP FOR APPS  •  SWIPE DOWN FOR SEARCH", 9f, Color.GRAY).apply {
            gravity = Gravity.CENTER; setPadding(0, 12, 0, 8)
        })
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downY = event.y; downX = event.x; true }
                MotionEvent.ACTION_UP -> {
                    val dy = event.y - downY
                    if (dy < -65) showDrawer()
                    else if (dy > 65) showDrawer(true)
                    true
                }
                else -> true
            }
        }
        setContentView(root)
        refreshDashboard()
    }

    private fun systemStatusText(): String {
        val batteryIntent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        val memory = android.app.ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(memory)
        val ramFree = memory.availMem / (1024L * 1024L)
        return "BATTERY  ${if (percent >= 0) "$percent%" else "--"}\nRAM FREE  ${ramFree} MB"
    }

    private fun refreshDashboard() {
        if (!::appArea.isInitialized) return
        appArea.removeAllViews()
        val apps = loadApps().filter { !isHidden(it.packageName) }.take(4)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        apps.forEach { info ->
            row.addView(appTile(info), LinearLayout.LayoutParams(0, 82, 1f))
        }
        appArea.addView(row)
    }

    private fun loadApps(): List<ApplicationInfo> {
        val pm = packageManager
        allApps = if (android.os.Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION") pm.getInstalledApplications(0)
        }.filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase(Locale.getDefault()) }
        return allApps
    }

    private fun isHidden(pkg: String) = prefs.getBoolean("hidden_$pkg", false)
    private fun isLocked(pkg: String) = prefs.getBoolean("locked_$pkg", false)

    private fun appTile(info: ApplicationInfo): View {
        val pm = packageManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(4, 5, 4, 5)
        }
        val icon = ImageView(this).apply {
            setImageDrawable(pm.getApplicationIcon(info))
            val size = prefs.getInt("icon_size", 48)
            layoutParams = LinearLayout.LayoutParams(size, size)
        }
        val name = label(pm.getApplicationLabel(info).toString(), 10f, cream)
        name.gravity = Gravity.CENTER
        box.addView(icon); box.addView(name)
        val badge = prefs.getInt("badge_${info.packageName}", 0)
        if (badge > 0) name.text = "${name.text}  •$badge"
        box.setOnClickListener { launchApp(info.packageName) }
        box.setOnLongClickListener { showAppOptions(info); true }
        return box
    }

    private fun showDrawer(focusSearch: Boolean = false) {
        drawerOpen = true
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 22, 18, 12)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("YOUR APPS  ♥", 20f, gold, true), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("Home") { renderHome() })
        root.addView(top)
        search = EditText(this).apply {
            hint = "Search installed apps"; setHintTextColor(Color.GRAY); setTextColor(cream)
            textSize = 15f; singleLine = true; setPadding(14, 10, 14, 10)
            background = background(panel); setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search, 0, 0, 0)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16; bottomMargin = 12 })
        val scroll = ScrollView(this)
        appArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(appArea)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("LONG-PRESS AN APP FOR HIDE / LOCK OPTIONS", 9f, Color.GRAY).apply {
            gravity = Gravity.CENTER; setPadding(0, 10, 0, 8)
        })
        setContentView(root)
        renderAppList("")
        search.addTextChangedListener(SimpleTextWatcher { renderAppList(it) })
        if (focusSearch) {
            search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun renderAppList(query: String) {
        if (!::appArea.isInitialized) return
        appArea.removeAllViews()
        val pm = packageManager
        val apps = loadApps().filter {
            !isHidden(it.packageName) &&
                pm.getApplicationLabel(it).toString().contains(query, true)
        }
        if (apps.isEmpty()) appArea.addView(label("No matching applications", 14f, Color.GRAY).apply { setPadding(8, 20, 8, 20) })
        apps.forEach { appArea.addView(appTile(app), LinearLayout.LayoutParams(-1, 72)) }
    }

    private fun showAppOptions(info: ApplicationInfo) {
        val name = packageManager.getApplicationLabel(info).toString()
        val choices = arrayOf(
            if (isHidden(info.packageName)) "Show in app drawer" else "Hide application",
            if (isLocked(info.packageName)) "Remove app lock" else "Require device authentication",
            "App information"
        )
        AlertDialog.Builder(this).setTitle(name).setItems(choices) { _, which ->
            when (which) {
                0 -> { prefs.edit().putBoolean("hidden_${info.packageName}", !isHidden(info.packageName)).apply(); if (drawerOpen) showDrawer() else renderHome() }
                1 -> {
                    prefs.edit().putBoolean("locked_${info.packageName}", !isLocked(info.packageName)).apply()
                    Toast.makeText(this, if (isLocked(info.packageName)) "App lock enabled" else "App lock removed", Toast.LENGTH_SHORT).show()
                }
                2 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${info.packageName}")))
            }
        }.show()
    }

    private fun launchApp(pkg: String) {
        if (isLocked(pkg)) {
            val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
            if (km.isDeviceSecure) {
                pendingPackage = pkg
                @Suppress("DEPRECATION")
                startActivityForResult(km.createConfirmDeviceCredentialIntent("Unlock application", "Authenticate to continue"), 901)
                return
            } else {
                Toast.makeText(this, "Set a screen lock in Android Settings first", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                return
            }
        }
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    @Deprecated("Android compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 901 && resultCode == RESULT_OK) {
            pendingPackage?.let { packageManager.getLaunchIntentForPackage(it)?.let(::startActivity) }
        }
        pendingPackage = null
    }

    private fun showSettings() {
        val items = arrayOf(
            "Change icon size",
            "Enable notification badge access",
            "Set this as default launcher",
            "Calendar permission",
            "Android security settings",
            "Refresh launcher"
        )
        AlertDialog.Builder(this).setTitle("DamiSam Launcher settings").setItems(items) { _, which ->
            when (which) {
                0 -> {
                    val sizes = arrayOf("Small (40 dp)", "Medium (48 dp)", "Large (56 dp)", "Extra large (64 dp)")
                    AlertDialog.Builder(this).setTitle("Icon size").setItems(sizes) { _, n ->
                        prefs.edit().putInt("icon_size", listOf(40,48,56,64)[n]).apply(); renderHome()
                    }.show()
                }
                1 -> startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                2 -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                3 -> requestPermissions(arrayOf(android.Manifest.permission.READ_CALENDAR), 300)
                4 -> startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                5 -> renderHome()
            }
        }.show()
    }

    private fun refreshDashboardUnused() {}

    private fun openCalendar() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setData(CalendarContract.CONTENT_URI))
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR))
        }
    }
}

private class SimpleTextWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
