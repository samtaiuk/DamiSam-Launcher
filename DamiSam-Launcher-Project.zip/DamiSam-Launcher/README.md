# DamiSam Launcher

Standalone Android launcher project with a black-and-gold business design.

## Build by uploading the project ZIP directly to GitHub

**Important:** GitHub Actions cannot read a workflow file while it is buried inside a ZIP. You must create the workflow file in the repository once, then you can upload the project ZIP directly for future builds.

### One-time GitHub setup (phone only)

1. Create a GitHub repository named `DamiSamLauncher`.
2. In the repository, tap **Add file** > **Create new file**.
3. Enter this exact filename: `.github/workflows/build-apk.yml`
4. Open the `BUILD-WORKFLOW-COPY.yml` file included in this ZIP, copy all its contents, and paste them into the GitHub editor.
5. Commit the new file to the `main` branch.

### Upload the project ZIP

1. Return to the repository's **Code** tab.
2. Tap **Add file** > **Upload files**.
3. Upload `DamiSamLauncher.zip` itself (do not extract it).
4. Commit the upload to `main`.
5. Open **Actions**. The workflow should start automatically. If it does not, open **Build DamiSam Launcher from uploaded ZIP** and tap **Run workflow**.

### Download and install the APK

1. Open the completed workflow run (green check mark).
2. Scroll to **Artifacts**.
3. Download `DamiSam-Launcher-APK`.
4. Extract the artifact ZIP and install `app-debug.apk`.
5. If Android blocks installation, allow your browser or file manager to install unknown apps.
6. Set DamiSam Launcher as your default Home app when Android prompts you, or go to Android Settings > Apps > Default apps > Home app.

### Important
- Keep only one project `.zip` file in the repository root. The workflow stops if it finds multiple ZIP files.
- The workflow file must be at `.github/workflows/build-apk.yml` in the repository itself; a workflow stored only inside the uploaded project ZIP will not run.
- The APK from this workflow is a debug build, suitable for testing, not a signed Play Store release.

## Features in this starter release
- Android HOME launcher activity
- Installed-app drawer and live app search
- Hide/show applications (long-press an app)
- App launch protection using the phone's secure lock-screen credential
- Icon-size preference
- Swipe up for app drawer and swipe down for search
- Clock/date dashboard and calendar shortcut
- Notification-listener service for best-effort notification counts

## Current limitations
- Weather is a placeholder; live weather service and location-consent flow are not integrated yet.
- Third-party Android home-screen widget hosting is not implemented yet.
- Battery/RAM dashboard telemetry and visible badge overlays are not complete yet.
- App lock uses the device PIN/pattern/password, not a separate DamiSam password.
- Some Android features depend on manufacturer and Android-version restrictions.

## Build details
- Application ID: `com.golddesk.launcher`
- Minimum Android: 6.0 (API 23)
- Compile SDK: 35
- Java/Kotlin target: 17


## Theme
DamiSam Launcher uses a romantic love-inspired palette: deep plum backgrounds, rose-pink accents, soft blush text, and a heart app icon.
